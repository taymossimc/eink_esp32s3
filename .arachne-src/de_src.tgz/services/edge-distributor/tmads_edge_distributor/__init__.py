"""TMAds edge distributor service."""
